package lab2;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class mainAssociation {
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		
		Books books=new Books();
		books.setTitle("Saaho");
		books.setPrice(10000d);
		AuthorDetails authorDetails=new AuthorDetails();
		books.setAuthorDetails(authorDetails);
		
		authorDetails.setName("vijaypawan");
		authorDetails.getList().add(books);
		em.getTransaction().begin();
		em.persist(authorDetails);
		em.persist(books);
		em.getTransaction().commit();
		
	}
}
