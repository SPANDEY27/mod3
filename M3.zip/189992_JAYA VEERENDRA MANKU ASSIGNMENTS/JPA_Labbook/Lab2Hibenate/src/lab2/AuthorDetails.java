package lab2;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class AuthorDetails {
		@Id
		@GeneratedValue
		private int authorId;
		private String name;
		@OneToMany(cascade=CascadeType.PERSIST)
		private List<Books> list=new ArrayList<Books>();
		
		public List<Books> getList() {
			return list;
		}

		public void setList(List<Books> list) {
			this.list = list;
		}

		public void setAuthorId(int authorId) {
			this.authorId = authorId;
		}

		public int getAuthorId() {
			return authorId;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		@Override
		public String toString() {
			return "AuthorDetails:-"+"\nauthorId=" + authorId + "\nName=" + name ;
		}
		
		
		
}
