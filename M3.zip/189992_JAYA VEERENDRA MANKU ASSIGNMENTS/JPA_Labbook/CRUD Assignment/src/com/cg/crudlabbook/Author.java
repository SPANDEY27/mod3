package com.cg.crudlabbook;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Author {
	@Id
	@Column(name="AUTHORID")
	private int authorId;
	@Column(name="FIRSTNAME")
	private String firstname;
	@Column(name="MIDDLENAME")
	private String middlename;
	@Column(name="LASTNAME")
	private String lastname;
	@Column(name="PHONENO")
	private String phoneNo;

	public Author() {
		super();

	}

	public Author(int authorId, String firstname, String middlename, String lastname, String phoneNo) {
		super();
		this.authorId = authorId;
		this.firstname = firstname;
		this.middlename = middlename;
		this.lastname = lastname;
		this.phoneNo = phoneNo;
	}

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", firstname=" + firstname + ", middlename=" + middlename
				+ ", lastname=" + lastname + ", phoneNo=" + phoneNo + "]";
	}

}
