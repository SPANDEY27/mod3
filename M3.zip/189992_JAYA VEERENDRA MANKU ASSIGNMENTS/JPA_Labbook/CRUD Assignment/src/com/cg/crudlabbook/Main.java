package com.cg.crudlabbook;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Main {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");

		EntityManager em = factory.createEntityManager();

		Author aut = new Author(112, "Vijay", "Pawan", "GOKAVARAPU", "9642272578");
		em.getTransaction().begin();
		em.persist(aut);
		em.getTransaction().commit();
		System.out.println("Data Saved");

		 //finding employee
		
		Author aut1 = em.find(Author.class, 111);
		System.out.println(aut1);

		// REMOVING AN EMPLOYEE
		
		em.getTransaction().begin();
		Author aut2 = em.find(Author.class, 105);
		System.out.println(aut2);
		em.remove(aut2);
		em.getTransaction().commit();
		System.out.println("After Commit");
		System.out.println(aut2);

		// update transaction

		em.getTransaction().begin();
		Author aut3 = em.find(Author.class, 107);
		System.out.println(aut3);
		aut3.setFirstname("VIJAYROCKZ");
		em.getTransaction().commit();
		System.out.println("After Commit");
		System.out.println(aut3);

	}
}