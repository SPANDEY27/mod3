package com.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.beans.Stock;
import com.stock.dao.StockRepository;
import com.stock.exception.StockException;

@Service //service implementation of the service class
public class StockServiceImpl implements StockService {
	
	@Autowired
	private StockRepository stockRepository;

	@Override //creating stocks
	public List<Stock> createStock(Stock stock) throws StockException {
		if(stockRepository.existsById(stock.getId())) {
			throw new StockException();
		}
		stock=calculateOrder(stock);
		stockRepository.save(stock);
		return viewAllStock();
	}
	// calculating the trading amount
	public Stock calculateOrder(Stock stock) { 
		
		int quantity=stock.getQuantity();
		double price=stock.getPrice();
		double tradingAmount=price*quantity;
		double brokerage;
		if(quantity>100)
		{
			brokerage=(tradingAmount*(0.3))/100;
		}
		else
		{
			brokerage=(tradingAmount*(0.5)/100);
		}
		stock.setAmount(tradingAmount);
		stock.setBrokerage(brokerage);
		return stock;
		
	}

	@Override //updating the stock
	public List<Stock> updateStock(Stock stock) throws StockException {
		if(!stockRepository.existsById(stock.getId())) {
			throw new StockException("Stock Id with " + stock.getId() + " Does not Exist");
		}
		Stock s = stockRepository.findById(stock.getId()).get();
		s.setPrice(stock.getPrice());
		s.setQuantity(stock.getQuantity());
		s=calculateOrder(s);
		stockRepository.save(s);
		return viewAllStock();
	}
	

	@Override //deleting the stock
	public List<Stock> deleteStock(int id) throws StockException {
		if(!stockRepository.existsById(id)) {
			throw new StockException("Stock Id with " + id + " Does not Exist");
		}
		stockRepository.deleteById(id);
		return viewAllStock();
	}

	@Override //view all stocks
	public List<Stock> viewAllStock() throws StockException {
		try {
			return stockRepository.findAll();
		} catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}

	@Override //finding by single stock
	public Stock findSingleStock(int id) throws StockException {
		if(!stockRepository.existsById(id)) {
			throw new StockException("Stock Id with " + id + " Does not Exist");
		}
		return stockRepository.findById(id).get();
	}

}
