package com.stock.service;

import java.util.List;

import com.stock.beans.Stock;
import com.stock.exception.StockException;
  
//Service methods will be in this class
public interface StockService {
	List<Stock> createStock(Stock stock) throws StockException;
	List<Stock> updateStock(Stock stock) throws StockException;
	List<Stock> deleteStock(int id) throws StockException;
	List<Stock> viewAllStock() throws StockException;
	Stock findSingleStock(int id) throws StockException;

}
