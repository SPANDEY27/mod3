package com.stock.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stock.beans.Stock;
import com.stock.exception.StockException;
import com.stock.service.StockService;

@RestController //controller of the this application
public class StockController {
	
	@Autowired
	private StockService stockService;
	
	@RequestMapping(value = "/stocks") //get all stocks
	public List<Stock> viewAllStock() throws StockException{
		return stockService.viewAllStock();
	}
	@PostMapping(value = "/addstocks") //adding data
	public List<Stock> createStock(@Valid @RequestBody Stock stock) throws StockException{
		return stockService.createStock(stock);
	}
	
	@DeleteMapping(value = "/delete/{id}") //deleting stocks
	public List<Stock> deleteStock(@PathVariable int id) throws StockException{
		
		return stockService.deleteStock(id);
	}
	@GetMapping(value = "/stocks/{id}") //finding by single stock
	public Stock findSingleStock(@PathVariable int id) throws StockException{
		return stockService.findSingleStock(id);
	}
	@PutMapping(value = "/update") //updating the fields
	public List<Stock> updateStock(@Valid @RequestBody Stock stock) throws StockException{
		return stockService.updateStock(stock);
	}

	

}
